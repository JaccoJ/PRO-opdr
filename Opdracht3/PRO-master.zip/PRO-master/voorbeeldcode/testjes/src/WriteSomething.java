package src;
public class WriteSomething
{
  public void write()
  {
    System.out.println("writing!");
  }

}
