package src;
public class UseCustomClass{
  public static void main(String[] args){
    WriteSomething ws = new WriteSomething();
    ws.write();
  }
}
